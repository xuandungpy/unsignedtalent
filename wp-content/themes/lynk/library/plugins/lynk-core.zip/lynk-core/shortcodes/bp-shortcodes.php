<?php

define( 'LYNK_CORE_PLUGIN_DIR', plugin_dir_path(  dirname( __FILE__ ) ) );

if ( ! function_exists('lynk_get_img_overlay') ) {
    function lynk_get_img_overlay() {
        global $lynk_config;

        if (isset($lynk_config['image_overlay'])) {
            return $lynk_config['image_overlay'];
        }
        return '';
    }
}

if ( ! function_exists( 'lynk_get_online_status' ) ) :
    function lynk_get_online_status($user_id) {
        $output = '';
        if (lynk_is_user_online($user_id)) {
            $output .= '<span class="lynk-online-status high-bg"></span>';
        } else {
            $output .= '<span class="lynk-online-status"></span>';
        }
        return $output;
    }
endif;

/* Get User online */
if (!function_exists('lynk_is_user_online')):
    /**
     * Check if a Buddypress member is online or not
     * @global object $wpdb
     * @param integer $user_id
     * @param integer $time
     * @return boolean
     */
    function lynk_is_user_online($user_id, $time=5)
    {
        global $wpdb;
        $sql = $wpdb->prepare( "
			SELECT u.user_login FROM $wpdb->users u JOIN $wpdb->usermeta um ON um.user_id = u.ID
			WHERE u.ID = %d
			AND um.meta_key = 'last_activity'
			AND DATE_ADD( um.meta_value, INTERVAL %d MINUTE ) >= UTC_TIMESTAMP()", $user_id, $time);
        $user_login = $wpdb->get_var( $sql );
        if(isset($user_login) && $user_login !=""){
            return true;
        }
        else {return false;}
    }
endif;


/**
 * Buddypress Activity Stream.
 */
add_shortcode( 'jvbpd_activity_stream', 'jvbpd_activity_stream_func' );
function jvbpd_activity_stream_func($atts, $content = null) {
	$output = '';
	require( trailingslashit( LYNK_CORE_PLUGIN_DIR ) . 'shortcodes/buddypress/jvbpd_activity_stream.php' );
	return $output;
}

/**
 * Buddypress Activity page.
 */
add_shortcode( 'jvbpd_activity_page', 'jvbpd_activity_page_func' );
function jvbpd_activity_page_func( $atts, $content = null ) {
	$output = '';
	require( trailingslashit( LYNK_CORE_PLUGIN_DIR ) . 'shortcodes/buddypress/jvbpd_activity_page.php' );
	return $output;
}

/**
 * Buddypress Groups carousel.
 */
add_shortcode( 'jvbpd_groups_carousel', 'jvbpd_groups_carousel_func' );
function jvbpd_groups_carousel_func($atts, $content = null) {
	$output = '';
	require( trailingslashit( LYNK_CORE_PLUGIN_DIR ) . 'shortcodes/buddypress/jvbpd_groups_carousel.php' );
	return $output;
}


/**
 * Buddypress Groups carousel.
 */
add_shortcode( 'jvbpd_groups_masonry', 'jvbpd_groups_masonry_func' );
function jvbpd_groups_masonry_func($atts, $content = null) {
	$output = '';
	require( trailingslashit( LYNK_CORE_PLUGIN_DIR ) . 'shortcodes/buddypress/jvbpd_groups_masonry.php' );
	return $output;
}


/**
 * Buddypress Members carousel.
 */
add_shortcode( 'jvbpd_members_carousel', 'jvbpd_members_carousel_func' );
function jvbpd_members_carousel_func($atts, $content = null) {
	$output = '';
	require( trailingslashit( LYNK_CORE_PLUGIN_DIR ) . 'shortcodes/buddypress/jvbpd_members_carousel.php' );
	return $output;
}


/**
 * Buddypress Members carousel.
 */
add_shortcode( 'jvbpd_members_masonry', 'jvbpd_members_masonry_func' );
function jvbpd_members_masonry_func($atts, $content = null) {
	$output = '';
	require( trailingslashit( LYNK_CORE_PLUGIN_DIR ) . 'shortcodes/buddypress/jvbpd_members_masonry.php' );
	return $output;
}

function lynk_vc_manipulate_shortcodes(){

	$lynk_member_types = Array( 'All' => 'all' );

    // Buddypress Groups Carousel
    vc_map(
        array(
            "name" => __("Groups Carousel"),
            "base" => "jvbpd_groups_carousel",
            "class" => "",
            "category" => __('BuddyPress'),
            "icon" => "bp-icon",
            "params" => array(
                array(
                    "type" => "dropdown",
                    "holder" => "div",
                    "class" => "",
                    "heading" => __("Type"),
                    "param_name" => "type",
                    "value" => array(
                        'Active' => 'active',
                        'Newest' => 'newest',
                        'Popular' => 'popular',
                        'Alphabetical' => 'alphabetical',
                        'Most Forum Topics' => 'most-forum-topics',
                        'Most Forum Posts' => 'most-forum-posts',
                        'Random' => 'random'
                    ),
                    "description" => __("The type of groups to display.")
                ),
                array(
                    "type" => "textfield",
                    "holder" => "div",
                    "class" => "",
                    "heading" => __("Number of groups"),
                    "param_name" => "number",
                    "value" => 12,
                    "description" => __("How many groups to get.")
                ),
                array(
                    "type" => "textfield",
                    "holder" => "div",
                    "class" => "",
                    "heading" => __("Minimum Items"),
                    "param_name" => "min_items",
                    "value" => 1,
                    "description" => __("Minimum number of items to show on the screen")
                ),
                array(
                    "type" => "textfield",
                    "holder" => "div",
                    "class" => "",
                    "heading" => __("Maximum Items"),
                    "param_name" => "max_items",
                    "value" => 6,
                    "description" => __("Maximum number of items to show on the screen")
                ),
                array(
                    "type" => "dropdown",
                    "holder" => "div",
                    "class" => "",
                    "heading" => __("Image Type"),
                    "param_name" => "image_size",
                    "value" => array(
                        'Full' => 'full',
                        'Thumbnail' => 'thumb'
                    ),
                    "description" => __("The size to get from buddypress")
                ),
                array(
                    "type" => "dropdown",
                    "holder" => "div",
                    "class" => "",
                    "heading" => __("Auto play"),
                    "param_name" => "autoplay",
                    "value" => array(
                        'No' => '',
                        'Yes' => 'yes'
                    ),
                    "description" => __("If the carousel should play automatically")
                ),
                array(
                    "type" => "dropdown",
                    "holder" => "div",
                    "class" => "",
                    "heading" => __("Avatar type"),
                    "param_name" => "rounded",
                    "value" => array(
                        'Rounded' => 'rounded',
                        'Square' => 'square'
                    ),
                    "description" => __("Rounded or square avatar")
                ),
                array(
                    "type" => "textfield",
                    "holder" => "div",
                    "class" => "",
                    "heading" => __("Image Width"),
                    "param_name" => "item_width",
                    "value" => 150,
                    "description" => __("The size of the group image")
                ),
                array(
                    "type" => "textfield",
                    "holder" => "div",
                    "class" => "",
                    "heading" => __("Class"),
                    "param_name" => "class",
                    "value" => '',
                    "description" => __("A class to add to the element for CSS referrences.")
                ),

            )
        )
    );

    // Buddypress Groups Masonry
    vc_map(
        array(
            "name" => __("Groups Masonry"),
            "base" => "jvbpd_groups_masonry",
            "class" => "",
            "category" => __('BuddyPress'),
            "icon" => "bp-icon",
            "params" => array(
                array(
                    "type" => "dropdown",
                    "holder" => "div",
                    "class" => "",
                    "heading" => __("Type"),
                    "param_name" => "type",
                    "value" => array(
                        'Active' => 'active',
                        'Newest' => 'newest',
                        'Popular' => 'popular',
                        'Alphabetical' => 'alphabetical',
                        'Most Forum Topics' => 'most-forum-topics',
                        'Most Forum Posts' => 'most-forum-posts',
                        'Random' => 'random'
                    ),
                    "description" => __("The type of groups to display.")
                ),
                array(
                    "type" => "textfield",
                    "holder" => "div",
                    "class" => "",
                    "heading" => __("Number of groups"),
                    "param_name" => "number",
                    "value" => 12,
                    "description" => __("How many groups to get.")
                ),
                array(
                    "type" => "dropdown",
                    "holder" => "div",
                    "class" => "",
                    "heading" => __("Avatar type"),
                    "param_name" => "rounded",
                    "value" => array(
                        'Rounded' => 'rounded',
                        'Square' => 'square'
                    ),
                    "description" => __("Rounded or square avatar")
                ),
                array(
                    "type" => "textfield",
                    "holder" => "div",
                    "class" => "",
                    "heading" => __("Class"),
                    "param_name" => "class",
                    "value" => '',
                    "description" => __("A class to add to the element for CSS referrences.")
                ),

            )
        )
    );

    //Activity Stream
    vc_map(
        array(
            "name" => __("Activity Stream"),
            "base" => "jvbpd_activity_stream",
            "class" => "",
            "category" => __('BuddyPress'),
            "icon" => "lynk-bp-icon",
            "params" => array(
                array(
                    "type" => "dropdown",
                    "holder" => "div",
                    "class" => "",
                    "heading" => __("Display"),
                    "param_name" => "show",
                    "value" => array(
                        'All' => false,
                        'Blogs' => 'blogs',
                        'Groups' => 'groups',
                        'Friends' => 'friends',
                        'Profile' => 'profile',
                        'Status' => 'status'
                    ),
                    "description" => __("The type of activity to show. It adds the 'object' parameter as in https://codex.buddypress.org/developer/loops-reference/the-activity-stream-loop/")
                ),
                array(
                    "type" => "textfield",
                    "holder" => "div",
                    "class" => "",
                    "heading" => __("Filter action"),
                    "param_name" => "filter_action",
                    "value" => '',
                    "description" => __("Example: activity_update<br> See action parameter from the filters section from https://codex.buddypress.org/developer/loops-reference/the-activity-stream-loop/")
                ),
                array(
                    "type" => "textfield",
                    "holder" => "div",
                    "class" => "",
                    "heading" => __("Number"),
                    "param_name" => "number",
                    "value" => '6',
                    "description" => __("How many activity streams to show")
                ),
                array(
                    "type" => "dropdown",
                    "holder" => "div",
                    "class" => "",
                    "heading" => __("Show post update form"),
                    "param_name" => "post_form",
                    "value" => array(
                        'No' => 'no',
                        'Yes' => 'yes'
                    ),
                    "description" => __("Shows the form to post a new update")
                ),
                array(
                    "type" => "dropdown",
                    "holder" => "div",
                    "class" => "",
                    "heading" => __("Bottom button"),
                    "param_name" => "show_button",
                    "value" => array(
                        'Yes' => 'yes',
                        'No' => 'no'
                    ),
                    "description" => __("Show a button with link to the activity page")
                ),
                array(
                    "type" => "textfield",
                    "holder" => "div",
                    "class" => "",
                    "heading" => __("Activity Button Label"),
                    "param_name" => "button_label",
                    "value" => 'View All Activity',
                    "dependency" => array(
                        "element" => "show_button",
                        "value" => "yes"
                    ),
                    "description" => __("Button text")
                ),
                array(
                    "type" => "textfield",
                    "holder" => "div",
                    "class" => "",
                    "heading" => __("Activity Button Link"),
                    "param_name" => "button_link",
                    "value" => '/activity',
                    "dependency" => array(
                        "element" => "show_button",
                        "value" => "yes"
                    ),
                    "description" => __("Put here the link to your activity page")
                )
            )
        )
    );

    //Activity Page
    vc_map(
        array(
            "name" => __("Activity Page"),
            "base" => "jvbpd_activity_page",
            "class" => "",
            "category" => __('BuddyPress'),
            "icon" => "lynk-bp-icon",
            "show_settings_on_create" => false
        )
    );


	 vc_map(
        array(
            "name" => __("Members Carousel"),
            "base" => "jvbpd_members_carousel",
            "class" => "",
            "category" => __('BuddyPress'),
            "icon" => "lynk-bp-icon",
            "params" => array(
                array(
                    "type" => "dropdown",
                    "holder" => "div",
                    "class" => "",
                    "heading" => __("Member Type"),
                    "param_name" => "member_type",
                    "value" => $lynk_member_types,
                    "description" => __("The type of members to display.")
                ),
                array(
                    "type" => "dropdown",
                    "holder" => "div",
                    "class" => "",
                    "heading" => __("Filter"),
                    "param_name" => "type",
                    "value" => array(
                        'Active' => 'active',
                        'Newest' => 'newest',
                        'Popular' => 'popular',
                        'Online' => 'online',
                        'Alphabetical' => 'alphabetical',
                        'Random' => 'random'
                    ),
                    "description" => __("Filter the members by.")
                ),
                array(
                    "type" => "textfield",
                    "holder" => "div",
                    "class" => "",
                    "heading" => __("Number of members"),
                    "param_name" => "number",
                    "value" => 12,
                    "description" => __("How many members to get.")
                ),
                array(
                    "type" => "textfield",
                    "holder" => "div",
                    "class" => "",
                    "heading" => __("Minimum Items"),
                    "param_name" => "min_items",
                    "value" => 1,
                    "description" => __("Minimum number of items to show on the screen")
                ),
                array(
                    "type" => "textfield",
                    "holder" => "div",
                    "class" => "",
                    "heading" => __("Maximum Items"),
                    "param_name" => "max_items",
                    "value" => 6,
                    "description" => __("Maximum number of items to show on the screen")
                ),
                array(
                    "type" => "dropdown",
                    "holder" => "div",
                    "class" => "",
                    "heading" => __("Image Type"),
                    "param_name" => "image_size",
                    "value" => array(
                        'Full' => 'full',
                        'Thumbnail' => 'thumb'
                    ),
                    "description" => __("The size to get from buddypress")
                ),
                array(
                    "type" => "dropdown",
                    "holder" => "div",
                    "class" => "",
                    "heading" => __("Avatar type"),
                    "param_name" => "rounded",
                    "value" => array(
                        'Rounded' => 'rounded',
                        'Square' => 'square'
                    ),
                    "description" => __("Rounded or square avatar")
                ),
                array(
                    "type" => "textfield",
                    "holder" => "div",
                    "class" => "",
                    "heading" => __("Image Width"),
                    "param_name" => "item_width",
                    "value" => 150,
                    "description" => __("The size of the member image")
                ),
                array(
                    "type" => "dropdown",
                    "holder" => "div",
                    "class" => "",
                    "heading" => __("Auto play"),
                    "param_name" => "autoplay",
                    "value" => array(
                        'No' => '',
                        'Yes' => 'yes'
                    ),
                    "description" => __("If the carousel should play automatically")
                ),
                array(
                    "type" => "dropdown",
                    "holder" => "div",
                    "class" => "",
                    "heading" => __("Online status"),
                    "param_name" => "online",
                    "value" => array(
                        'Show' => 'show',
                        'Hide' => 'noshow'
                    ),
                    "description" => __("Show online status")
                ),
                array(
                    "type" => "textfield",
                    "holder" => "div",
                    "class" => "",
                    "heading" => __("Class"),
                    "param_name" => "class",
                    "value" => '',
                    "description" => __("A class to add to the element for CSS referrences.")
                ),

            )
        )
    );



    // Buddypress Members Masonry

    vc_map(
        array(
            "name" => __("Members Masonry"),
            "base" => "jvbpd_members_masonry",
            "class" => "",
            "category" => __('BuddyPress'),
            "icon" => "lynk-bp-icon",
            "params" => array(
                array(
                    "type" => "dropdown",
                    "holder" => "div",
                    "class" => "",
                    "heading" => __("Member Type"),
                    "param_name" => "member_type",
                    "value" => $lynk_member_types,
                    "description" => __("The type of members to display.")
                ),
                array(
                    "type" => "dropdown",
                    "holder" => "div",
                    "class" => "",
                    "heading" => __("Filter"),
                    "param_name" => "type",
                    "value" => array(
                        'Active' => 'active',
                        'Newest' => 'newest',
                        'Popular' => 'popular',
                        'Online' => 'online',
                        'Alphabetical' => 'alphabetical',
                        'Random' => 'random'
                    ),
                    "description" => __("Filter the members by.")
                ),
                array(
                    "type" => "textfield",
                    "holder" => "div",
                    "class" => "",
                    "heading" => __("Number of members"),
                    "param_name" => "number",
                    "value" => 12,
                    "description" => __("How many members to get.")
                ),
                array(
                    "type" => "dropdown",
                    "holder" => "div",
                    "class" => "",
                    "heading" => __("Avatar type"),
                    "param_name" => "rounded",
                    "value" => array(
                        'Rounded' => 'rounded',
                        'Square' => 'square'
                    ),
                    "description" => __("Rounded or square avatar")
                ),
                array(
                    "type" => "dropdown",
                    "holder" => "div",
                    "class" => "",
                    "heading" => __("Online status"),
                    "param_name" => "online",
                    "value" => array(
                        'Show' => 'show',
                        'Hide' => 'noshow'
                    ),
                    "description" => __("Show online status")
                ),
                array(
                    "type" => "textfield",
                    "holder" => "div",
                    "class" => "",
                    "heading" => __("Class"),
                    "param_name" => "class",
                    "value" => '',
                    "description" => __("A class to add to the element for CSS referrences.")
                ),

            )
        )
    );

}
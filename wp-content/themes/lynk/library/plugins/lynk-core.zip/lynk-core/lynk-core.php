<?php
/**
 * Plugin Name: Lynk Core
 * Description: This plugin is requested for Lynk wordpress theme. it loads shortcodes and some custom code for javo buddypress theme.
 * Version: 1.0.3
 * Author: Javo Themes
 * Author URI: http://javothemes.com/
 * Text Domain: lynk
 * Domain Path: /languages/
 * License: GPLv2 or later */

if( ! defined( 'ABSPATH' ) )
	die;

if( ! class_exists( 'Lynk_Core' ) ) :

	class Lynk_Core {

/* Const : */
		/**
		 * Debug mode on/off
		 * @const boolean
		 * @since 1.0.0
		 */
		const DEBUG = false;

/* Private : */
		/**
		 * Core Theme Template Name
		 * @var string
		 * @since 1.0.0
		 */
		private $theme_name = 'lynk';

		/**
		 * Core Theme Template Name
		 * @var Array
		 * @since 1.0.0
		 * @array_key Theme name
		 * @array_value Core name
		 */
		private $theme_names = Array(
			'lynk' => 'jvbpd'
		);

		/**
		 * Get Theme Information Object
		 * @var object
		 * @since 1.0.0
		 */
		private $theme			= null;

/* Public : */

		/**
		 * Instance object
		 * @var object
		 * @since 1.0.0
		 */
		public static $instance;

		public $prefix = false;

/* Protected : */
		/**
		 * Get Import Directory
		 * @var string
		 * @since 1.0.0
		 */
		public $import_path	= false;

		/**
		 * Get Export Directory
		 * @var string
		 * @since 1.0.0
		 */
		protected $export_path	= true;

		public function __construct( $file ) {
			$this->file = $file;
			$this->folder = basename( dirname( $this->file ) );
			$this->path = dirname( $this->file );
			$this->assets_url = esc_url( trailingslashit( plugins_url( '/assets/', $this->file ) ) );
			$this->import_path = trailingslashit( $this->path ) . 'import';
			$this->export_path = trailingslashit( $this->path ) . 'export';
			$this->include_path = trailingslashit( $this->path ) . 'includes';
			$this->module_path = trailingslashit( $this->path ) . 'modules';
			$this->shortcode_path = trailingslashit( $this->path ) . 'shortcodes';
			$this->template_path = trailingslashit( $this->path ) . 'templates';

			if( $this->theme_check( $this->theme_names ) ) {
				$this->load_files();
				$this->register_hooks();
			}

			do_action( 'jvbpd_core_init' );
		}

		public function theme_check( $theme_names=Array() ) {
			$this->theme = wp_get_theme();
			$this->template = $this->theme->get( 'Name' );
			if( $this->theme->get( 'Template' ) ) {
				$this->parent = wp_get_theme(  $this->theme->get( 'Template' ) );
				$this->template = $this->parent->get( 'Name' );
			}
			$this->template = str_replace( ' ', '_', strtolower( $this->template ) );

			$strPrefix = sanitize_key( $this->template );
			$isAllowTheme = false;
			if( array_key_exists( $strPrefix, $theme_names ) ) {
				$this->prefix = $theme_names[ $strPrefix ];
				$isAllowTheme = true;
			}
			return $isAllowTheme;
		}

		public function load_files() {
			$arrFIles		= Array();
			$arrFIles[]		= $this->shortcode_path . '/core-shortcodes.php';
			$arrFIles[]		= $this->import_path . '/javo-import.php';
			$arrFIles[]		= $this->export_path . '/javo-export.php';
			$arrFIles[]		= $this->include_path . '/class-admin.php';
			$arrFIles[]		= $this->include_path . '/class-admin-helper.php';
			$arrFIles[]		= $this->include_path . '/class-portfolio.php';
			$arrFIles[]		= $this->include_path . '/class-template.php';

			if( !empty( $arrFIles ) ) foreach( $arrFIles as $filename ) {
				if( file_exists( $filename ) ) {
					require_once( $filename );
				}
			}
		}

		public function register_hooks() {
			add_action( 'init', Array( $this, 'load_core' ), 99 );
			load_plugin_textdomain('lynk', false, $this->folder . '/languages/');

			add_filter( 'jvbpd_doc_url', array( $this, 'doc_url' ) );
			add_filter( 'jvbpd_support_url', array( $this, 'support_url' ) );

			if( class_exists( 'Lynk_Core_Admin' ) )
				new Lynk_Core_Admin;
		}

		public function load_core() {
			if( function_exists( 'jvbpd_register_shortcodes' ) ) {
				jvbpd_register_shortcodes( $this->theme_names[ $this->template ] . '_' );
			}

			if( class_exists( 'Lynk_Import' ) ) {
				$this->import = new Lynk_Import;
				$GLOBALS[ 'jvbpd_import' ]	= $this->import;
			}

			if( class_exists( 'jvbpd_Export' ) && self::DEBUG ) {
				$this->export = new jvbpd_Export;
				$GLOBALS[ 'jvbpd_Export' ]	= $this->export;
			}

			$this->tempalte = new Lynk_Core_Template;
		}

		public function doc_url() {
			return esc_url_raw( 'doc.wpjavo.com/lynk/' );
		}

		public function support_url() {
			return esc_url_raw( 'javothemes.com/lynk/' );
		}

		public static function get_instance( $file=null ) {
			if( null === self::$instance )
				self::$instance = new Lynk_Core( $file );

			return self::$instance;
		}
	}
endif;
if( ! function_exists( 'jvlynkCore' ) ) {
	function jvlynkCore() {
		return Lynk_Core::get_instance( __FILE__ );
	}
	jvlynkCore();
}
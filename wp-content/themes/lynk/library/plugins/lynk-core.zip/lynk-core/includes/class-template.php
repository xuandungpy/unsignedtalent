<?php
class Lynk_Core_Template {
	public function __construct() {
		$this->regsiterHooks();
		$this->loadLess();
	}

	public function regsiterHooks() {
		add_action( 'wp_footer', array( $this, 'single_control_buttons' ) );
	}

	public function single_control_buttons() {
		$post = get_post();
		if( ! in_array( get_post_type( $post ), Array( 'post' ) ) || get_post_status( $post ) != 'pending' ) {
			return false;
		}

		$this->load_template( 'part-single-layer-preview', '.php', array( 'post' => $post ) );
	}

	public function loadLess() {
		add_filter( 'jvbpd_enqueue_less_array', array( $this, 'core_less' ) );
		add_filter( 'jvbpd_enqueue_css_array', array( $this, 'core_csses' ) );
	}

	public function core_less( $lesses=Array() ) {
		$lesses[ 'single-style-less' ] = Array(
			'dir' => jvlynkCore()->assets_url . 'less',
			'file' => 'single.less',
		);
		return $lesses;
	}

	public function core_csses( $csses=Array() ) {
		$lesses[ 'single-style-css' ] = Array(
			'dir' => jvlynkCore()->assets_url . 'css',
			'file' => 'single.css',
		);
		return $csses;
	}

	public function load_template( $template_name, $extension='.php' , $params=Array(), $_once=true ) {

		if( !empty( $params ) ) {
			extract( $params );
		}

		$strFileName = jvlynkCore()->template_path . '/' . $template_name . $extension;
		$strFileName = apply_filters( 'jvbpd_core_load_template', $strFileName, $template_name );

		if( file_exists( $strFileName ) ) {
			if( $_once ) {
				require_once $strFileName;
			}else{
				require $strFileName;
			}
			return true;
		}
		return false;
	}

}
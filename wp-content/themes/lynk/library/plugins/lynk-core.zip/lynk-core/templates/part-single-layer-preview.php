<div class="jvbpd-single-preview-layer right">
	<h3 class="title"><?php esc_html_e( "Preview", 'javospot' ); ?></h3>
	<?php
	if( function_exists( 'lava_bpp' ) && get_post_type() == 'post' ) {
		lava_bpp()->template->single_control_buttons();
	} ?>
</div>
<?php
class Lynk_Core_Admin extends Lynk_Core {
	private $modules = Array();

	private $module_option_format = 'lynk_term_%s_module';

	public function __construct() {
		add_action( 'lynk_modules_loaded', Array( $this, 'get_modules' ) );
		add_filter( 'manage_edit-category_columns' , Array( $this, 'custom_category_column' ) );
		add_filter( 'manage_category_custom_column' , Array( $this, 'custom_category_contents' ), 10, 3 );
		add_action( 'category_add_form_fields', Array( $this, 'append_module_selector' ) );
		add_action( 'category_edit_form_fields', Array( $this, 'append_module_selector' ) );
		add_action( 'created_category', Array( $this, 'update_module_name' ), 10, 2 );
		add_action( 'edited_category', Array( $this, 'update_module_name' ), 10, 2 );
		add_action( 'deleted_term_taxonomy', Array( $this, 'trash_module_name' ) );
		add_action( 'jvbpd_contact_send_mail', Array( $this, 'sendsMsnage' ) );

		add_filter( 'jvbpd_theme_setting_pages', array( $this, 'bp_page' ) );
		add_filter( 'jvbpd_theme_setting_pages', array( $this, 'custom_ts_page' ) );
	}

	public function get_term_module( $term_id, $default=false ) {
		return get_option( sprintf( $this->module_option_format, $term_id ), $default );
	}

	public function get_term_module_post_length( $term_id, $default=false ) {
		return get_option( sprintf( $this->module_option_format . '_length' , $term_id ), $default );
	}

	public function get_term_module_columns( $term_id, $default=false ) {
		return get_option( sprintf( $this->module_option_format . '_columns' , $term_id ), $default );
	}

	public function get_modules( $modules ) {
		$this->modules	= Array_diff(
			Array_keys( $modules ),
			Array(
				'module2'
			)
		);
	}

	public function custom_category_column( $columns ) {
		return wp_parse_args(
			$columns,
			Array(
				'cb'				=> '<input type="checkbox">',
				'name'			=>__( "Name", 'lynk' ),
				'description'	=>__( "Description", 'lynk' ),
				'lynk_module'	=> __( "Module Name", 'lynk' ),
			)
		);
	}

	public function custom_category_contents( $dep, $column_name, $term_id ) {
		switch( $column_name ) {
			case 'lynk_module' :
				if(  ! $module_name = $this->get_term_module( $term_id ) )
					$module_name	 = __( "None", 'lynk' );
				echo $module_name;
			break;
		}
	}

	public function append_module_selector( $objTaxonomy ) {

		if( ! is_Array( $this->modules ) )
			return;

		$term_id	= 0;
		if( is_object( $objTaxonomy ) )
			$term_id = $objTaxonomy->term_id;

		$arrOptionModules					=
		$arrOptionModules_columns	= Array();
		foreach( $this->modules as $module_name )
			$arrOptionModules[]	= sprintf(
				"<option value=\"{$module_name}\"%s>{$module_name}</option>",
				selected( $module_name == $this->get_term_module( $term_id ), true, false )
			);

		for( $intColumn=1; $intColumn <= 3; $intColumn++ )
			$arrOptionModules_columns[]	= sprintf(
				"<option value=\"{$intColumn}\"%s>{$intColumn} %s</option>",
				selected( $intColumn == $this->get_term_module_columns( $term_id ), true, false ),
				_n( "Column", "Columns", $intColumn, 'lynk' )
			);

		echo join( "\n",
			Array(
				'<tr>',
					'<th>',
						__( "Archive Module", 'lynk' ),
					'</th>',
					'<td>',
						sprintf( '<h4>%s</h4>', __( "Module Name", 'lynk' ) ),
						'<fieldset class="inner">',
							'<select name="lynk_category[_module]">',
							'<option value="">' . __( "Default Template", 'lynk' ) . '</option>',
							join( "\n", $arrOptionModules ),
							'</select>',
						'</fieldset>',
						sprintf( '<h4>%s</h4>', __( "Module Columns", 'lynk' ) ),
						'<fieldset class="inner">',
							'<select name="lynk_category[_module_columns]">',
							join( "\n", $arrOptionModules_columns ),
							'</select>',
						'</fieldset>',
						sprintf( '<h4>%s</h4>', __( "Post Content Length", 'lynk' ) ),
						'<fieldset class="inner">',
							sprintf( '<input type="number" name="lynk_category[_module_length]" value="%s">', $this->get_term_module_post_length( $term_id ) ),
						'</fieldset>',
					'</td>',
				'</tr>',
			)
		);
	}

	public function update_module_name( $term_id, $taxonomy_id ){

		if( empty( $term_id ) || empty( $_POST[ 'lynk_category' ] ) )
			return;

		foreach( $_POST[ 'lynk_category'] as $key_name => $value )
			update_option( 'lynk_term_' . $term_id . $key_name, $value );
	}

	public function trash_module_name( $term_id ) {
		delete_option( $this->module_option_format );
		delete_option( $this->module_option_format . '_length' );
		delete_option( $this->module_option_format . '_columns' );
	}

	static function send_mail_content_type(){ return 'text/html';	}
	public function sendsMsnage() {
		$jvbpd_query = new jvbpd_array( $_POST );
		$jvbpd_this_return = Array();
		$jvbpd_this_return['result'] = false;
		$meta = Array(
			'to' => $jvbpd_query->get('to', NULL),
			'subject' => $jvbpd_query->get('subject', esc_html__('Untitled Mail', 'lynk')).' : '.get_bloginfo('name'),
			'from' => sprintf("From: %s<%s>\r\n", get_bloginfo('name'),			$jvbpd_query->get('from', get_option('admin_email') )
			),
			'content' => $jvbpd_query->get( 'content', NULL ),
		);

		if(
			$jvbpd_query->get('to', NULL) != null &&
			$jvbpd_query->get('from', NULL) != null
		){
			add_filter( 'wp_mail_content_type', Array(__CLASS__, 'send_mail_content_type') );
			$mailer = wp_mail(
				$meta['to']
				, $meta['subject']
				, $meta['content']
				, $meta['from']
			);
			$jvbpd_this_return['result'] = $mailer;
			remove_filter( 'wp_mail_content_type', Array(__CLASS__, 'send_mail_content_type'));
		};

		die( $jvbpd_this_return );
	}

	public function bp_page( $pages=Array() ) {

		if( function_exists( 'BuddyPress' ) ) {
			$pages[ 'boddypress' ] = Array(
				esc_html__( "BuddyPress", 'lynk' ), false,
				'priority' => 71,
				'external' => jvlynkCore()->template_path . '/admin-theme-settings-bp.php',

			);
		}
		return $pages;
	}

	public function custom_ts_page( $pages=array() ) {
		if( function_exists( 'lava_bpp' ) ) {
			$pages[ 'lava_bpp' ] = Array(
				esc_html__( "Lava Bp Post", 'lynk' ), false,
				'priority' => 71,
				'external' => jvlynkCore()->template_path . '/admin-theme-settings-lvbpp.php',
			);
		}
		return $pages;
	}
}
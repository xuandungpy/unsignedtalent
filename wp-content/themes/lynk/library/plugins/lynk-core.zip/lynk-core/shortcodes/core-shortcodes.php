<?php
/**
 *	Javo Shortcodes
 *
 *	@Since	1.0.0
 */


/** Core Classes */
require_once 'functions-shortcode.php';
require_once 'class-shortcode.php';
require_once 'class-module.php';

if( !function_exists( 'jvbpd_register_shortcodes' ) ) :

	function jvbpd_register_shortcodes( $prefix ){

	/**
	 *	Variables
	 */
		$dirShortcode		= trailingslashit( dirname( __FILE__ ) );
		$dirModule			= Lynk_Core::$instance->module_path . '/';

		$arrGroupStrings	= Array(
			'header'		=> __( "Header", 'lynk' ),
			'content'		=> __( "Content", 'lynk' ),
			'advanced'		=> __( "Advanced", 'lynk' ),
			'effect'		=> __( "Effect", 'lynk' ),
			'style'			=> __( "Style", 'lynk' ),
			'filter'		=> __( "Filter", 'lynk' ),
		);

		list(
			$groupHeader,
			$groupContent,
			$groupAdvanced,
			$groupEffect,
			$groupStyle,
			$groupFilter
		) = Array_values( $arrGroupStrings );

	/**
	 *	Shortcodes Part
	 */
		$arrShortcodeDEFAULTS		= Array(

			/* Shortcode 1 */
			'block1'				=> Array(
				'name'				=> __( "Block 1", 'lynk'),
				'icon'				=> 'jv-vc-shortcode-icon shortcode-block-1',
				'column'			=> 3,
				'hide_avatar'		=> true,
				'params'			=> Array(
					Array(
						'type'		=> 'dropdown',
						'group'		=> $groupStyle,
						'heading'		=> __( "Display Thumbnail", 'lynk'),
						'holder'		=> 'div',
						'param_name'	=> '_display_thumbnail',
						'value'		=> Array(
							__( "Enable", 'lynk' ) => '',
							__( "Disable", 'lynk' ) => '1'
						)
					),
					Array(
						'type'					=> 'dropdown'
						, 'group'				=> $groupStyle
						, 'heading'				=> __( "Display Post Border", 'lynk')
						, 'holder'				=> 'div'
						, 'param_name'			=> 'display_post_border'
						, 'value'				=> Array(
							__( "Enable", 'lynk' ) => '',
							__( "Disable", 'lynk' ) => '1'
						)
					)
				),
				'hover_style'	=> true,
			),

			/* Shortcode 3 */
			'block3'			=> Array(
				'name'			=> __( "Block 3", 'lynk'),
				'filter'		=> true,
				'column'		=> 3,
				'icon'			=> 'jv-vc-shortcode-icon shortcode-block-3',
				'hide_avatar'	=> true,
			),

			/* Shortcode 7 */
			'block7'			=> Array(
				'name'			=> __( "Block 7", 'lynk'),
				'more'			=> true,
				'column'		=> 2,
				'icon'			=> 'jv-vc-shortcode-icon shortcode-block-7',
				'hover_style'	=> true,
			),

			/* Shortcode 8 */
			'block8'			=> Array(
				'name'				=> __( "Block 8", 'lynk')
				, 'more'				=> true
				, 'icon'				=> 'jv-vc-shortcode-icon shortcode-block-8'
				, 'column'			=> 2
			),

			/* Shortcode 10 */
			'block10'		=> Array(
				'name'			=> __( "Block 10", 'lynk'),
				'more'			=> true,
				'column'		=> 3,
				'icon'			=> 'jv-vc-shortcode-icon shortcode-block-10',
				'hover_style'	=> true,
			),

			/* Shortcode 11 */
			'block11'		=> Array(
				'name'			=> __( "Block 11", 'lynk'),
				'more'			=> true,
				'icon'			=> 'jv-vc-shortcode-icon shortcode-block-11',
				'column'		=> 3,
				'hover_style'	=> true,
			),

			/* Shortcode 12 */
			'block12'			=> Array(
				'name'				=> __( "Block 12", 'lynk')
				, 'icon'				=> 'jv-vc-shortcode-icon shortcode-block-12'
				, 'column'			=> 3
				, 'more'				=> true
			),

			/* Shortcode 16  */
			'block16'		=> Array(
				'name'			=> __( "Block 16", 'lynk'),
				'icon'			=> 'jv-vc-shortcode-icon shortcode-block-15',
				'column'		=> 3,
				'more'			=> true,
				'hover_style'	=> true,
			),

			/* Shortcode Grid 1  */
			'big_grid1'		=> Array(
				'name'			=> __( "Grid 1", 'lynk'),
				'more'			=> true,
				'fixed_count'	=> true,
				'icon'			=> 'jv-vc-shortcode-icon shortcode-grid1',
				'hover_style'	=> true,
			),

			/* Shortcode Grid 3  */
			'big_grid3'			=> Array(
				'name'				=> __( "Grid 3", 'lynk'),
				'icon'				=> 'jv-vc-shortcode-icon shortcode-grid3',
				'more'				=> true,
				'hover_style'		=> true,
			),

			/* Shortcode Login1 */
			'login1'				=> Array(
				'name'				=> __( "Login 1", 'lynk')
				, 'icon'				=> 'jv-vc-shortcode-icon shortcode-login1'
				//, 'no_param'			=> true
			),
		);

	if( defined( 'Lynk_Core::DEBUG' ) && Lynk_Core::DEBUG ) {
		/* Shortcode 20  */
		$arrShortcodeDEFAULTS[ 'block20' ]	=
			Array(
				'name'				=> __( "Block 20 ( ALL MODULE )", 'lynk')
				, 'icon'				=> 'jv-vc-shortcode-icon shortcode-block-20'
				, 'fixed_count'	=> true
			);
	}


	/**
	 *	Modules Part
	 */
		$arrModuleDEFAULTS				= Array(
			'module1'					=> Array( 'file' => $dirModule . 'module1.php' )
			, 'module2'					=> Array( 'file' => $dirModule . 'module2.php' )
			, 'module3'					=> Array( 'file' => $dirModule . 'module3.php' )
			, 'module4'					=> Array( 'file' => $dirModule . 'module4.php' )
			, 'module5'					=> Array( 'file' => $dirModule . 'module5.php' )
			, 'module6'					=> Array( 'file' => $dirModule . 'module6.php' )
			, 'module8'					=> Array( 'file' => $dirModule . 'module8.php' )
			, 'module9'					=> Array( 'file' => $dirModule . 'module9.php' )
			, 'module12'				=> Array( 'file' => $dirModule . 'module12.php' )
			, 'module13'				=> Array( 'file' => $dirModule . 'module13.php' )
			, 'module14'				=> Array( 'file' => $dirModule . 'module14.php' )
			, 'moduleBpGrid'			=> Array( 'file' => $dirModule . 'module-Bp-Grid.php' )
			, 'moduleBpGridNoBG'		=> Array( 'file' => $dirModule . 'module-Bp-Grid-No-BG.php' )
			, 'moduleSmallGrid'			=> Array( 'file' => $dirModule . 'module-SmallGrid.php' )
			, 'moduleBigGrid'			=> Array( 'file' => $dirModule . 'module-BigGrid.php' )
			, 'moduleHorizontalGrid'	=> Array( 'file' => $dirModule . 'module-HorizontalGrid.php' )
			, 'moduleWC1'				=> Array( 'file' => $dirModule . 'module-wc1.php' )
		);


		$arrShortcodes	= apply_filters( 'lynk_shortcodes_args', $arrShortcodeDEFAULTS );
		$arrModules		= apply_filters( 'lynk_modules_args', $arrModuleDEFAULTS );
		$arrCommonParam	= Array(

			/**
			 *	@group : header
			 */
			 Array(
				'type'						=> 'dropdown'
				, 'group'					=> $groupHeader
				, 'heading'				=> __( "Header Type", 'lynk')
				, 'holder'				=> 'div'
				, 'class'					=> ''
				, 'param_name'		=> 'filter_style'
				, 'value'					=> Array(
					__( "None", 'lynk' )					=> ''
					, __( "Style1", 'lynk' )				=> 'general'
					, __( "Style2", 'lynk' )				=> 'linear'
					, __( "Box Style 1", 'lynk' )				=> 'box'
				)
			)

			/** Shortcode Title */
			, Array(
				'type'						=> 'textfield'
				, 'group'					=> $groupHeader
				, 'heading'				=> __( "Title", 'lynk' )
				, 'holder'				=> 'div'
				, 'dependency'		=> Array(
					'element'			=> 'filter_style'
					, 'not_empty'		=> true
				)
				, 'param_name'		=> 'title'
				, 'value'					=> ''
			)

			/** Shortcode Subtitle */
			, Array(
				'type'						=> 'textfield'
				, 'group'					=> $groupHeader
				, 'heading'				=> __( "Sub Title (Only Header Type Style3)", 'lynk' )
				, 'holder'				=> 'div'
				, 'dependency'		=> Array(
					'element'			=> 'filter_style'
					, 'value'				=> 'paragraph'
				)
				, 'param_name'		=> 'subtitle'
				, 'value'					=> ''
			)


			/**
			 *	@group : Style
			 */

			 /** Custom Post Taxonomies */
			, Array(
				'type'						=> 'dropdown'
				, 'group'					=> $groupFilter
				, 'heading'					=> __( "Show / Hide Filter", 'lynk')
				, 'holder'					=> 'div'
				, 'param_name'			=> 'hide_filter'
				, 'value'						=> Array(
					__( "Show", 'lynk' ) => '',
					__( "Hide", 'lynk' ) => '1'
				)
			),

			Array(
				'type'			=> 'css_editor',
				'group'			=> $groupStyle,
				'heading'		=> __( 'Css', 'my-text-domain' ),
				'param_name'	=> 'css',
			),

			/** Primary Color */
			Array(
				'type'						=> 'colorpicker'
				, 'group'					=> $groupStyle
				, 'heading'				=> __( "Primary Color", 'lynk' )
				, 'holder'				=> 'div'
				, 'param_name'		=> 'primary_color'
				, 'value'					=> ''
			)

			/** Primary Font Color */
			, Array(
				'type'						=> 'colorpicker'
				, 'group'					=> $groupStyle
				, 'heading'				=> __( "Primary Font Color", 'lynk' )
				, 'holder'				=> 'div'
				, 'param_name'		=> 'primary_font_color'
				, 'value'					=> ''
			)

			/** Primary Border Color */
			, Array(
				'type'						=> 'colorpicker'
				, 'group'					=> $groupStyle
				, 'heading'				=> __( "Primary Border Color", 'lynk' )
				, 'holder'				=> 'div'
				, 'param_name'		=> 'primary_border_color'
				, 'value'					=> ''
			)

			/** Post TItle Font Color */
			, Array(
				'type'						=> 'colorpicker'
				, 'group'					=> $groupStyle
				, 'heading'				=> __( "Post Title Color", 'lynk' )
				, 'holder'				=> 'div'
				, 'param_name'		=> 'post_title_font_color'
				, 'value'					=> ''
			)

			/** Post Title Size  */
			, Array(
				'type'					=> 'textfield'
				, 'group'				=> $groupStyle
				, 'heading'				=> __( "Post Title Font Size", 'lynk' )
				, 'holder'				=> 'div'
				, 'description'		=> __( "Pixcel", 'lynk' )
				, 'param_name'		=> 'post_title_font_size'
				, 'value'					=> ''
			)

			/** Post TItle Capitalize */
			, Array(
				'type'					=> 'dropdown'
				, 'group'				=> $groupStyle
				, 'heading'				=> __( "Post Title Transform", 'lynk' )
				, 'holder'				=> 'div'
				, 'param_name'		=> 'post_title_transform'
				, 'value'					=> Array(
					__( "Inheritance", 'lynk' )	=> 'inherit',
					__( "Uppercase", 'lynk' )	=> 'uppercase',
					__( "Lowercase", 'lynk' )	=> 'lowercase',
				)
			)

			/** Post Meta Font Color */
			, Array(
				'type'						=> 'colorpicker'
				, 'group'					=> $groupStyle
				, 'heading'				=> __( "Post Meta Font Color", 'lynk' )
				, 'holder'				=> 'div'
				, 'param_name'		=> 'post_meta_font_color'
				, 'value'					=> ''
			)

			/** Post Describe Font Color */
			, Array(
				'type'						=> 'colorpicker'
				, 'group'					=> $groupStyle
				, 'heading'				=> __( "Post Description Font Color", 'lynk' )
				, 'holder'				=> 'div'
				, 'param_name'		=> 'post_describe_font_color'
				, 'value'					=> ''
			)

			/** Category Tag Visibility */
			, Array(
				'type'			=> 'dropdown',
				'group'			=> $groupStyle,
				'heading'		=> __( "Display Category Tags", 'lynk' ),
				'holder'		=> 'div',
				'param_name'	=> 'display_category_tag',
				'value'			=> Array(
					__( "Visible", 'lynk' )	=> '',
					__( "HIdden", 'lynk' )	=> 'hide'
				)
			)

			/** Category Tag Color */
			, Array(
				'type'			=> 'colorpicker',
				'group'			=> $groupStyle,
				'heading'		=> __( "Category Tags Background Color", 'lynk' ),
				'holder'		=> 'div',
				'dependency'	=> Array(
					'element'	=> 'display_category_tag',
					'value'		=> Array( '' )
				),
				'param_name'	=> 'category_tag_color',
				'value'			=> '#666'
			)

			/** Category Tag Hover Color */
			, Array(
				'type'			=> 'colorpicker',
				'group'			=> $groupStyle,
				'heading'		=> __( "Category Tags Background Hover Color", 'lynk' ),
				'holder'		=> 'div',
				'dependency'	=> Array(
					'element'	=> 'display_category_tag',
					'value'		=> Array( '' )
				),
				'param_name'	=> 'category_tag_hover_color',
				'value'			=> ''
			)

			/** Pre-loader Style */
			, Array(
				'type'			=> 'dropdown',
				'group'			=> $groupStyle,
				'heading'		=> __( "Pre-loader Style Type", 'lynk'),
				'holder'		=> 'div',
				'class'			=> '',
				'param_name'	=> 'loading_style',
				'value'			=>
					Array(
						__( "None", 'lynk' )		=> '',
						__( "Rectangle", 'lynk' )	=> 'rect',
						__( "circle", 'lynk' )		=> 'circle'
					)
			)

			/**
			 *	@group : Filter
			 */

			/** Post Type */
			, Array(
				'type'					=> 'dropdown'
				, 'group'				=> $groupFilter
				, 'heading'				=> __( "Post Type", 'lynk' )
				, 'holder'				=> 'div'
				, 'param_name'		=> 'post_type'
				, 'value'					=> apply_filters( 'lynk_shortcodes_post_types', Array( 'post' ) )
			)

			/** Order Type */
			, Array(
				'type'					=> 'dropdown'
				, 'group'				=> $groupFilter
				, 'heading'				=> __( "Order By", 'lynk' )
				, 'holder'				=> 'div'
				, 'param_name'		=> 'order_by'
				, 'value'					=> apply_filters( 'lynk_shortcodes_order_by',
					Array(
						__( "None", 'lynk' )			=> '',
						__( "Post Title", 'lynk' )	=> 'title',
						__( "Date", 'lynk' )			=> 'date',
						__( "Random", 'lynk' )	=> 'rand',
					)
				)
			)

			/** Order Type */
			, Array(
				'type'					=> 'dropdown'
				, 'group'				=> $groupFilter
				, 'heading'				=> __( "Order Type", 'lynk' )
				, 'holder'				=> 'div'
				, 'dependency'		=> Array(
					'element'			=> 'order_by'
					, 'not_empty'		=> true
				)
				, 'param_name'		=> 'order_'
				, 'value'					=> Array(
					__( "Descending ( default )", 'lynk' )	=> '',
					__( "Ascending", 'lynk' )		=> 'ASC'
				)
			)

			/** Filter Taxonomy */
			, Array(
				'type'					=> 'dropdown'
				, 'group'				=> $groupFilter
				, 'heading'				=> __( "Category Filter", 'lynk')
				, 'holder'				=> 'div'
				, 'dependency'		=> Array(
					'element'			=> 'post_type'
					, 'value'				=> 'post'
				)
				, 'param_name'		=> 'filter_by'
				, 'value' => jvbpd_shortcode_taxonomies( 'post', Array( __( "None", 'lynk' )	=> '' ) )
			)

			/** Custom Post Taxonomies */
			, Array(
				'type'					=> 'checkbox'
				, 'group'				=> $groupFilter
				, 'heading'				=> __( "Use Custom Terms", 'lynk')
				, 'holder'				=> 'div'
				, 'dependency'		=> Array(
					'element'			=> 'filter_by'
					, 'not_empty'		=> true
				)
				,  'description'		=> __( "To display specific terms only, please enable. if you use custom terms.", 'lynk' )
				, 'param_name'		=> 'custom_filter_by_post'
				, 'value'					=> Array( __( "Enable", 'lynk' ) => '1' )
			)

			/** Header / Filter Custom Terms */
			, Array(
				'type'						=> 'textfield'
				, 'group'					=> $groupFilter
				, 'heading'				=> __( "Custom Terms IDs", 'lynk')
				, 'holder'				=> 'div'
				, 'dependency'		=> Array(
					'element'			=> 'custom_filter_by_post'
					, 'value'				=> '1'
				)
				, 'param_name'		=> 'custom_filter'
				, 'description'			=> __( "Enter category IDs separated by commas (ex: 13,23,18). To exclude categories please add '-' (ex: -9, -10)", 'lynk' )
				, 'value'					=> ''
			)

			/**
			 *	@group : Advanced
			 */
			 , Array(
				'type'						=> 'dropdown'
				, 'group'					=> $groupAdvanced
				, 'heading'				=> __( "Display description", 'lynk' )
				, 'holder'				=> 'div'
				, 'param_name'		=> 'module_contents_hide'
				, 'value'					=> Array(
					__( "Enable", 'lynk' )		=> '',
					__( "Disable", 'lynk' )		=> 'hide'
				)
			)
			, Array(
				'type'						=> 'textfield'
				, 'group'					=> $groupAdvanced
				, 'heading'				=> __( "Limit length of description", 'lynk' )
				, 'holder'				=> 'div'
				, 'description'			=> __( "( 0 = Unlimited )", 'lynk' )
				, 'param_name'		=> 'module_contents_length'
				, 'value'					=> '0'
			)
		);

		$arrCommonParam		= apply_filters( $prefix . 'commonParam', $arrCommonParam, $arrGroupStrings );
		$arrPaginationParam		= Array(

			/**
			 *	@group : Style
			 */

			 /** Pagination Style */
			Array(
				'type'						=> 'dropdown'
				, 'group'					=> $groupStyle
				, 'heading'				=> __( "Load More Type", 'lynk')
				, 'holder'				=> 'div'
				, 'class'					=> ''
				, 'param_name'		=> 'pagination'
				, 'value'					=> Array(
					__( "None", 'lynk' )				=> ''
					, __( "Pagination", 'lynk' )	=> 'number'
					, __( "Load More", 'lynk' )	=> 'loadmore'
					, __( "Previous & Next Button", 'lynk' )	=> 'prevNext'
				)
			)
		);

		$arrAmountParam							=  Array(

			/**
			 *	@group : Advanced
			 */

			/** Posts Per Page */
			Array(
				'type'										=> 'textfield'
				, 'group'									=> $groupAdvanced
				, 'heading'									=> __( "Number of posts to load", 'lynk')
				, 'holder'									=> 'div'
				, 'class'										=> ''
				, 'param_name'							=> 'count'
				, 'value'										=> 5
			)
		);

		/** module hover style **/
		$arrHoverStyleParam = Array(
			/**
			 *	@group : Effect
			 */
			Array(
				'type'			=> 'dropdown'
				, 'group'		=> $groupEffect
				, 'heading'		=> __( "Module Hover Effect", 'lynk')
				, 'holder'		=> 'div'
				, 'class'		=> ''
				, 'param_name'	=> 'hover_style'
				, 'value'		=> Array(
					__( "None", 'lynk' )				=> ''
					, __( "Effect 1 (Zoom In)", 'lynk' )	=> 'zoom-in'
					, __( "Effect 2 (Dark Fade In)", 'lynk' )	=> 'dark-fade-in'
				)
			)
		);

		// Parse Shortcodes
		if( ! empty( $arrShortcodes ) ) : foreach( $arrShortcodes as $scdName => $scdAttr ) :

			// File Exists
			if( isset( $scdAttr[ 'file' ] ) )
				$fnShortcode		= $scdAttr[ 'file' ];
			else
				$fnShortcode		= $dirShortcode . 'shortcode-' .$scdName . '.php';

			// Other Shortcode
			if( ! file_exists( $fnShortcode ) )
				continue;
			else
				require_once $fnShortcode;

			// Shortcode icon
			$scdAttr[ 'icon' ]	= isset( $scdAttr[ 'icon' ] ) ? $scdAttr[ 'icon' ] : 'javo-vc-icon';

			// Default Setting
			$scdAttr				= wp_parse_args(
				Array(
					'base'			=> 'jvbpd_' . $scdName
					, 'category'	=> __( "Javo", 'lynk' )
				)
				, $scdAttr
			);

			// Merge Parametters
			if( empty( $scdAttr[ 'params' ] ) ){
				$scdAttr[ 'params']	= $arrCommonParam;
			}else{
				$scdAttr[ 'params']	= wp_parse_args( $scdAttr[ 'params'], $arrCommonParam );
			}

			if( isset( $scdAttr[ 'more' ] ) )
				$scdAttr[ 'params']	= wp_parse_args( $arrPaginationParam, $scdAttr[ 'params'] );

			if( isset( $scdAttr[ 'column' ] ) && 0 < intVal( $scdAttr[ 'column' ] ) )
			{
				$arrColumn					= Array();
				for( $intCount = 1; $intCount <= $scdAttr[ 'column' ]; $intCount ++ )
					$arrColumn[ $intCount . ' ' . _n( "Column", "Columns", $intCount, 'lynk' ) ] = $intCount;

				$scdAttr[ 'params']		= wp_parse_args(
					Array(
						Array(
							'type'				=> 'dropdown'
							, 'group'			=> $groupContent
							, 'heading'			=> __( "Columns", 'lynk')
							, 'holder'			=> 'div'
							, 'class'				=> ''
							, 'param_name'	=> 'columns'
							, 'value'				=> $arrColumn
						)
					)
					, $scdAttr[ 'params']
				);
			}

			if( isset( $scdAttr[ 'hide_thumb' ] ) )
			{
				$scdAttr[ 'params']		= wp_parse_args(
					Array(
						Array(
							'type'				=> 'dropdown'
							, 'group'			=> $groupContent
							, 'heading'			=> __( "Display Posts Thumbnails", 'lynk')
							, 'holder'			=> 'div'
							, 'class'				=> ''
							, 'param_name'	=> 'hide_thumbnail'
							, 'value'				=> Array(
								__( "Visible", 'lynk' )	=> '',
								__( "Hidden", 'lynk' )	=> 'hide'
							)
						)
					)
					, $scdAttr[ 'params']
				);
			}

			if( isset( $scdAttr[ 'hide_avatar' ] ) )
			{
				$scdAttr[ 'params']		= wp_parse_args(
					Array(
						Array(
							'type'				=> 'dropdown'
							, 'group'			=> $groupContent
							, 'heading'			=> __( "Display User Avatar", 'lynk')
							, 'holder'			=> 'div'
							, 'class'				=> ''
							, 'param_name'	=> 'hide_avatar'
							, 'value'				=> Array(
								__( "Visible", 'lynk' )	=> false,
								__( "Hidden", 'lynk' )	=> true
							)
						)
					)
					, $scdAttr[ 'params']
				);
			}

			if( !isset( $scdAttr[ 'fixed_count' ] ) )
				$scdAttr[ 'params' ]	= wp_parse_args( $arrAmountParam, $scdAttr[ 'params'] );

			/* module hover style */
			if(isset($scdAttr['hover_style']))
				$scdAttr[ 'params' ] = wp_parse_args($arrHoverStyleParam, $scdAttr['params']);

			if( isset( $scdAttr[ 'no_param' ] ) && $scdAttr[ 'no_param' ] )
				$scdAttr[ 'params' ] = Array();

			add_shortcode( 'jvbpd_' . $scdName, 'lynk_parse_shortcode' );

			// Register shortcode in visual composer
			if( function_exists( 'vc_map' ) )
				vc_map( $scdAttr );

		endforeach; endif;

		$arrOtherShortcode = apply_filters( 'jvbpd_other_shortcode_array', Array() );
		if( !empty( $arrOtherShortcode ) ) foreach( $arrOtherShortcode as $shortcode_name => $shortcode_callback )
			add_shortcode( 'jvbpd_' . $shortcode_name, $shortcode_callback );


		if( function_exists( 'vc_map' ) ) :
			// Mailchimp
			/*
			vc_map(array(
				'base'						=> 'lynk_mailchimp'
				, 'name'						=> __( "Mailchimp 1", 'lynk' )
				, 'icon'						=> 'jv-vc-shortcode-icon shortcode-mailchimp'
				, 'category'				=> __('Javo', 'lynk')
				, 'params'					=> Array(
					Array(
						'type'				=> 'dropdown'
						, 'heading'			=> __("LIST ID", 'lynk')
						, 'holder'			=> 'div'
						, 'class'				=> ''
						, 'param_name'	=> 'list_id'
						, 'description'	=> __('You need to create a list id on mailchimp site, if you don`t have', 'lynk')
						, 'value'			=> apply_filters( 'lynk_mail_chimp_get_lists',  Array(
							__( "Theme Setting > General > Plugin > API KEY (Please add your API key)", 'lynk') => ''
						) )
					)
				)
			) );
			*/
		endif;


		do_action( 'lynk_shortcodes_loaded', $arrShortcodes );

		// Parse Modules
		if( ! empty( $arrModules ) ) : foreach( $arrModules as $artName => $artAttr ) {
			if( ! file_exists( $artAttr[ 'file'] ) )
				continue;
			require_once $artAttr[ 'file' ];
		} endif;

		do_action( 'lynk_modules_loaded', $arrModules );
	}

	// Shortcode contents output
	function lynk_parse_shortcode( $attr, $content=null, $tag )
	{
		if( !class_exists( $tag ) )
			return '';

		$obj	= new $tag();
		return $obj->output( $attr, $content );
	}
endif;

require_once( 'bp-shortcodes.php' );

if( function_exists( 'lynk_vc_manipulate_shortcodes' ) ) {
	add_action('vc_before_init', 'lynk_vc_manipulate_shortcodes');
}


require_once( 'class-other-shortcode.php' );

require_once( 'shortcode-bp_member_list.php' );
require_once( 'shortcode-bp_active_member_list.php' );
require_once( 'shortcode-bp_group_list.php' );
require_once( 'shortcode-login3.php' );
require_once( 'shortcode-register.php' );
jvbpd_bp_member_list::getInstance();
jvbpd_bp_active_member_list::getInstance();
jvbpd_bp_group_list::getInstance();
jvbpd_login3::getInstance();
jvbpd_register::getInstance();
<?php
$arrPages = jvbpd_tso()->getPages(); ?>
<div class="jvbpd_ts_tab javo-opts-group-tab hidden" tar="boddypress">
	<h2> <?php esc_html_e( "BuddyPress Setting", 'jvfrmtd' ); ?> </h2>
	<table class="form-table">
	<tr><th>
		<?php esc_html_e( "Common", 'jvfrmtd' );?>
		<span class="description"></span>
	</th><td>

		<h4><?php esc_html_e("Default Cover Image For Members, Groups",'jvfrmtd'); ?></h4>
		<fieldset class="inner">
			<input type="text" name="jvbpd_ts[bp_no_image]" value="<?php echo esc_attr( jvbpd_tso()->get('bp_no_image') );?>" tar="bp_no_image">
			<input type="button" class="button button-primary fileupload" value="<?php esc_attr_e('Select Image', 'jvfrmtd');?>" tar="bp_no_image">
			<input class="fileuploadcancel button" tar="bp_no_image" value="<?php esc_attr_e('Delete', 'jvfrmtd');?>" type="button">
			<div class="description"><?php esc_html_e("If there is no members, groups cover images, it will be replaced", 'jvfrmtd');?></div>
			<p>
				<?php esc_html_e("Preview",'jvfrmtd'); ?><br>
				<img src="<?php echo esc_attr( jvbpd_tso()->get('bp_no_image') );?>" tar="bp_no_image">
			</p>
		</fieldset>

		<h4><?php esc_html_e( "BBPress Topic Front Form Page Setting", 'jvfrmtd');?>: </h4>
		<fieldset  class="inner">
			<select name="jvbpd_ts[bp_permalink]">
				<option value=""><?php esc_html_e( "Select a page", 'jvfrmtd' ); ?></option>
				<?php
				foreach( $arrPages as $objPage ) {
					printf(
						'<option value="%1$s"%3$s>%2$s</option>',
						$objPage->ID, $objPage->post_title,
						selected( jvbpd_tso()->get( 'bp_permalink' ) == $objPage->ID, true, false )
					);
				} ?>
			</select>
			<div class="description"><?php esc_html_e("If you haven't created a topic front form page, please create a page with bbpress topic form shortcode. And then choose the page", 'jvfrmtd');?></div>
		</fieldset>

		<?php
		$arrBpPages = Array(
			'bp_profile_' => esc_html__( "Profile", 'jvfrmtd' ),
			'bp_mypage_' => esc_html__( "Profile( MyPage )", 'jvfrmtd' ),
			'bp_members_' => esc_html__( "Members( List )", 'jvfrmtd' ),
			'bp_group_' => esc_html__( "Group( Single )", 'jvfrmtd' ),
			'bp_groups_' => esc_html__( "Groups( List )", 'jvfrmtd' ),
			'bp_activity_' => esc_html__( "Activity", 'jvfrmtd' ),
			'bp_register_' => esc_html__( "Register Page", 'jvfrmtd' ),
			'bb_' => esc_html__( "BBpress", 'jvfrmtd' ),
			'bb_single_' => esc_html__( "BBpress( Single )", 'jvfrmtd' ),
		);

		if( !empty( $arrBpPages ) ) {

			foreach( $arrBpPages as $strOption => $strOptionLabel ) {
				?>
				<h4><?php echo esc_html( $strOptionLabel ); ?></h4>
				<fieldset class="inner">
					<div>
						<span><?php esc_html_e( "Layout", 'jvfrmtd' ); ?> : </span>
						<select name="jvbpd_ts[<?php echo esc_attr( $strOption ); ?>sidebar]">
							<option value=""><?php esc_html_e( "Select one", 'jvfrmtd' ); ?></option>
							<?php
							foreach(
								Array( 'left' => esc_html__( "Left", 'jvfrmtd' ), 'right' => esc_html__( "Right", 'jvfrmtd' ), 'full' => esc_html__( "Full", 'jvfrmtd' ) )
								as $strPositionOption => $strPositionLabel
							) {
								printf(
									'<option value="%1$s"%3$s>%2$s</option>',
									$strPositionOption, $strPositionLabel,
									selected( $strPositionOption == jvbpd_tso()->get( $strOption . 'sidebar' ), true, false )
								);
							} ?>
						</select>
					</div>
					<?php do_action( 'jvbpd_theme_settings_bp_options_after', $strOption ); ?>
				</fieldset>
				<?php
			}
		} ?>
	</td></tr><tr><th>
		<?php esc_html_e( "Header", 'jvfrmtd' );?>
		<span class="description"></span>
	</th><td>
		<h4><?php esc_html_e( "Forum Background",'jvfrmtd' ); ?></h4>
		<fieldset class="inner">
			<input type="text" name="jvbpd_ts[bb_forum_header_image]" value="<?php echo esc_attr( jvbpd_tso()->get( 'bb_forum_header_image' ) );?>" tar="bb_forum_header_image">
			<input type="button" class="button button-primary fileupload" value="<?php esc_attr_e( 'Select Image', 'jvfrmtd' );?>" tar="bb_forum_header_image">
			<input class="fileuploadcancel button" tar="bb_forum_header_image" value="<?php esc_attr_e('Delete', 'jvfrmtd' );?>" type="button">
			<p>
				<?php esc_html_e("Preview",'jvfrmtd' ); ?><br>
				<img src="<?php echo esc_attr( jvbpd_tso()->get('bb_forum_header_image') );?>" tar="bb_forum_header_image">
			</p>
		</fieldset>

		<?php
		$arBpHeaderOptions = Array(
			'bp_profile_' => esc_html__( "Profile / Group Header", 'jvfrmtd' ),
			'bb_directories_' => esc_html__( "BBpress Directories Header( Forum, Topic List )", 'jvfrmtd' ),
			'bb_forum_' => esc_html__( "Single Toipic Header", 'jvfrmtd' ),
		);

		foreach( $arBpHeaderOptions as $key_prefix => $optionTitle ) {
			?>
			<h4><?php echo esc_html( $optionTitle ); ?></h4>
			<fieldset  class="inner">
				<dl>
					<dt><?php esc_html_e( "Navi Type", 'jvfrmtd');?></dt>
					<dd>
						<select name="jvbpd_ts[<?php echo esc_attr( $key_prefix ); ?>header_relation]">
							<?php
							foreach( Array(
								esc_html__( "Default menu", 'jvfrmtd' ) => "relative",
								esc_html__( "Transparency menu", 'jvfrmtd' ) => "absolute"
							) as $label => $value ) {
								printf( "<option value='{$value}' %s>{$label}</option>", selected( $value == jvbpd_tso()->get( $key_prefix . 'header_relation' ), true, false ) );
							} ?>
						</select>
						<div class="description"><?php esc_html_e("Caution: If you choose transparent menu type, page's main text contents ascends as much as menu's height to make menu transparent.", 'jvfrmtd');?></div>
					</dd>
				</dl>

				<dl>
					<dt><?php esc_html_e( "Header Menu Skin", 'jvfrmtd');?></dt>
					<dd>
						<select name="jvbpd_ts[<?php echo esc_attr( $key_prefix ); ?>header_skin]">
							<?php
							foreach( $jvbpd_options['header_skin'] as $label => $value ) {
								printf( "<option value='{$value}' %s>{$label}</option>", selected( $value == jvbpd_tso()->get( $key_prefix . 'header_skin' ), true, false ) );
							} ?>
						</select>
						<div class="description"><?php esc_html_e("Depends on this option, logo changes to the color appropriate to the skin and if selected logo of skin option is not uploaded, theme's basic logo will be shown.", 'jvfrmtd');?></div>
					</dd>
				</dl>
				<dl>
					<dt><?php esc_html_e( "Initial Header Background Color", 'jvfrmtd');?></dt>
					<dd><input type="text" name="jvbpd_ts[<?php echo esc_attr( $key_prefix ); ?>header_bg]" value="<?php echo esc_attr( jvbpd_tso()->get( $key_prefix . 'header_bg', "#506ac5"));?>" class="wp_color_picker" data-default-color="#506ac5"></dd>
				</dl>
				<dl>
					<dt><?php esc_html_e( "Initial Header Transparency", 'jvfrmtd');?></dt>
					<dd>
						<input type="text" name="jvbpd_ts[<?php echo esc_attr( $key_prefix ); ?>header_opacity]" value="<?php echo (float)jvbpd_tso()->get( $key_prefix . 'header_opacity', 1); ?>">
						<div class="description"><?php esc_html_e("Please enter numerical value from 0.0 to 1.0. The higher the value you enter, the more opaque it will be. Ex. 1=opaque, 0= invisible.", 'jvfrmtd');?></div>
					</dd>
				</dl>
				<dl>
					<dt><?php esc_html_e( "Navi Shadow", 'jvfrmtd');?></dt>
					<dd>
						<select name="jvbpd_ts[<?php echo esc_attr( $key_prefix ); ?>header_shadow]">
							<?php
							foreach( $jvbpd_options['able_disable'] as $label => $value ) {
								printf( "<option value='{$value}' %s>{$label}</option>", selected( $value == jvbpd_tso()->get( $key_prefix . 'header_shadow' ), true, false ) );
							} ?>
						</select>
					</dd>
				</dl>
			</fieldset>
			<?php
		} ?>
	</tr></tr>
	</table>
</div>